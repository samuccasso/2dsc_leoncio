const idade = 16
// Crie uma variável para cada um dos 
// Dados listados: (nome, sobrenome, telefone, estaCasado= true ou false)
// Imprima cada um dos valores com console.log(<variavel

console.log(idade) 
const Nome = Ana
console.log(Nome)
const Sobrenome = Caçadora 
console.log(Sobrenome)
const Telefone = 
console.log(Telefone)
const estaCasado = "false"
console.log(estaCasado)