//VARIÁVEIS UNITÁRIAS
const nome = 'Aghata Nunes'
const nome2 = 'Juju do Pix'
const nome3 = 'Phonsy'
// ...


//VARIÁVEIS DE ARRAY
const nomes = ['Aghata Nunes', 'Juju do Pix', 'Phonsy']

// IMPRIMINDO OS VALORES DO ARRAY
console.log(nomes)
console.log(nomes[2])
names[10] = "Ygona" // CRIANDO DINAMICAMENTE
console.log(nomes[2])