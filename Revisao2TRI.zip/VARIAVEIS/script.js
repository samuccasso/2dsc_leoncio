// # ID ou identificador 
//. Class ou classe CSS
const comidas = document.querySelectorAll('.comidas');
// prompt = pergunta ao usuário (interage)
const comida = prompt('Digite sua comida n°1')

comida.innerText = comida1;